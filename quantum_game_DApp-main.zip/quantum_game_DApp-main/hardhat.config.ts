// hardhat.config.ts

// hardhat.config.ts
import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.28",
    settings: {
      optimizer: {
        enabled: true,
        runs: 100, // Lower value optimizes for deployment size
      },
      viaIR: true,
    },
  },
  networks: {
    hardhat: {
      chainId: 31337,
      mining: {
        auto: false,
        interval: 5000, // 5 seconds
      },
      blockGasLimit: 30000000,
    },
    localhost: {
      url: "http://127.0.0.1:8545",
      chainId: 31337,
      gas: 30000000,
      blockGasLimit: 30000000,
    },
  },
};

export default config;

/*
import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const config: HardhatUserConfig = {
  solidity: "0.8.28",

  networks: {
    // This config applies to both `npx hardhat node` and in‐process Hardhat network
    hardhat: {
      chainId: 31337,
      mining: {
        auto: false, // don't mine on every TX
        interval: 5_000, // mine one block every 5000 ms
      },
    },
    // So that `localhost` RPC also works if you point Metamask at it
    localhost: {
      url: "http://127.0.0.1:8545",
      chainId: 31337,
    },
  },
};

export default config;
 */
